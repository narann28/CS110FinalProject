# lab 7 demo
Created a chatroom with functionality to look at other chatrooms and create new ones

Commands you need to run:
1) npm install
2) npm install mongodb
3) npm install mongoose
4) npm run start

